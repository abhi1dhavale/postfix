app.service('polishNotationService', function() {
	
    this.polishNotationEvaluator = function(postfix){
		
		var arrResult = [];
        var arrExpression = postfix.split(" "); //splitting string based on spaces between characters.
				
        for( var i = 0; i < arrExpression.length; i++ ) {	
		
            if( !isNaN( arrExpression[i] ) ) {      
                arrResult.push( arrExpression[i] );
				
            } else { 
			
				var a = arrResult.pop();
				var b = arrResult.pop();
				var operator = arrExpression[i];
				
				switch(operator){
					case "+": 
						arrResult.push(parseInt(a) + parseInt(b));
						break;
					case "-":
						arrResult.push(parseInt(a) - parseInt(b));
						break;
					case "*":
						arrResult.push(parseInt(a) * parseInt(b));
						break;
					case "/":
						arrResult.push(parseInt(a) / parseInt(b));
						break;
					case "^":
						arrResult.push(Math.pow(parseInt(b), parseInt(a)));
						break;					
				}
            }
        }
		return arrResult;
		//Check stack has only one value at the end. 
        /*if(arrResult.length > 1 || arrResult.length <=0 || isNaN(arrResult[0])) {
            $scope.error = "Invalid value! Please check arrExpression format.";
        } else {
			var result = arrResult.pop();
			return result;
        }*/
    }
});