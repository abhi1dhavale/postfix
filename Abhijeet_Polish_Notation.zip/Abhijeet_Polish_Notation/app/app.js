var app = angular.module('polishNotationModule', []);

